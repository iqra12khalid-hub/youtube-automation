CONTEXT: A scene from "The One-Eyed Island", a fictional PG adventure film. No blood, no injuries shown - people are pushed and tumble.

STEP 1 - CHECK EVERY FILE FIRST. Before you make anything, open and study each uploaded image one by one:
- 1_CHAR_MONSTER_sheet.jpg = THE MONSTER. A one-eyed protector (a hero, not a villain). Bald, grey cracked skin, ONE big eye in the middle of the forehead, sharp teeth, torn mustard-yellow cloth tunic over one shoulder, brown leather strap across the chest, round metal charms on cords around the neck, rope belt, barefoot. The SCALE panel shows its size: only ONE HEAD taller than a warrior. Never a giant, never a muscular body-builder.
- 2_CHAR_WARRIOR_sheet.jpg = THE WARRIORS. All warriors look exactly like this: dark carved wooden mask with white stripes and red-yellow eye rings, black feathers on top, straw cape on the shoulders, cowrie-shell and bone necklace, white dot body paint, rope belt with a burlap loincloth, rope anklets, spear.
- 4_CHAR_NOOR_sheet.jpg = NOOR. Young woman, brown hair in a ponytail, red and white stripes painted across her forehead and cheeks, dirty white T-shirt, small gold necklace, dirty dark jeans, dark shoes. She never smiles.
Ignore all printed words and labels on the sheets - they are only notes for you.

STEP 2 - ONCE YOU HAVE CHECKED EVERY FILE, put each character into the video exactly as their reference sheet shows: same face, same costume, same colors, same body size. Do not invent new designs.

STEP 3 - MAKE THE VIDEO.
Make this video 15 seconds, one generation, ONE continuous shot with no cuts.
NO FIRST FRAME - draw the opening picture yourself: night, the dark jungle right behind the old stone temple, drifting smoke and distant orange torch lights. THE MONSTER (exactly as 1_CHAR_MONSTER_sheet.jpg) and NOOR (exactly as 4_CHAR_NOOR_sheet.jpg) are coming out of the smoke toward the camera.
Characters in this video: THE MONSTER (1_CHAR_MONSTER_sheet.jpg), NOOR (4_CHAR_NOOR_sheet.jpg), THE WARRIORS (2_CHAR_WARRIOR_sheet.jpg, only as far-away torch carriers). No chief.
Place: the dark jungle right behind the old stone temple - giant tree roots, mossy rocks, hanging vines, mist, moonlight through the leaves. Then a narrow, hidden tunnel opening in the rocks, half covered by a curtain of vines.

{
 "title": "Into the Tunnel",
 "duration_seconds": 15,
 "aspect_ratio": "16:9",
 "camera": "handheld tracking shot following them from behind and the side, then it slowly stops at the tunnel and stays still. No cuts.",
 "shots": [
  {"time": "0-4s", "action": "THE MONSTER limps out of the smoke into the dark jungle behind the temple, holding its hurt shoulder, NOOR under its good arm helping it walk. Behind them, orange torch lights and shouting WARRIORS search through the smoke."},
  {"time": "4-8s", "action": "They push through ferns and over big tree roots. NOOR keeps looking back, frightened. THE MONSTER stops at a mossy rock wall and pulls aside a thick curtain of hanging vines - behind it is a narrow dark tunnel opening."},
  {"time": "8-11s", "action": "THE MONSTER lets NOOR go in first, then squeezes in after her and lets the vines fall closed behind them."},
  {"time": "11-15s", "action": "Seen from inside the dark tunnel looking out through the vines: torch lights and WARRIORS run past outside without seeing them. The torch light fades away. Silence. In the cool blue darkness THE MONSTER slowly sinks down against the tunnel wall, breathing heavily, and NOOR kneels beside it, looking at its shoulder with worry."}
 ],
 "rules": "Every character matches its reference sheet for the whole video. THE MONSTER stays one head taller than NOOR.",
 "dialogue": "far-away warriors shouting in an invented tribal language. Noor whispers nothing - only her fast breathing.",
 "style": "realistic live-action adventure film, 35mm film grain, deep blue moonlit night, mist, warm torch light only in the distance, the tunnel in cool blue darkness, tense then quiet and emotional",
 "sound": "heavy breathing, leaves and twigs crunching, distant shouting and running feet, vines rustling, then the shouting fades to silence, water dripping inside the tunnel, the monster's slow heavy breath. No music.",
 "negative": "blood, wounds shown, giant monster, different Noor face, chief, daylight, cuts, Noor smiling, English words, text, watermark"
}
