LITTLE BRAVE HORN - THE NEXT 5 CLIPS FOR DOLA
==============================================
Already done: CLIP 01, CLIP 04, CLIP 06.

SETTINGS FOR EVERY CLIP: Seedance 2.0 - 4K - 15 seconds - 16:9 - one clip per generation.
Every prompt starts with the 5 rules Dola must confirm first.

START NOW (first frames are already inside the folders):
  CLIP 02  - first frame = last frame of CLIP 01 (1_FIRST_FRAME.png is in the folder)
  CLIP 03  - no first frame needed
  CLIP 05  - first frame = last frame of CLIP 04 (1_FIRST_FRAME.png is in the folder, watermark removed)
  CLIP 07  - no first frame needed

WAIT:
  CLIP 08  - needs the LAST FRAME of CLIP 07. Do NOT start it until CLIP 07 is finished.
             Send CLIP 07 to Claude and Claude will cut the exact last frame.

HOW: open the clip folder, upload the images in number order (1, 2, 3...),
then copy everything in PASTE_THIS_IN_DOLA.txt into Dola.
