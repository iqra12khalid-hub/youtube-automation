README - START HERE
Make ONE video, 15 seconds, 16:9, one continuous shot. Use 0_FIRST_FRAME.jpg as the first frame. Use the 4 reference sheets for the characters and the place. The full prompt is below (same as PASTE_THIS_IN_DOLA.txt).

CONTEXT: A scene from "The One-Eyed Island", a fictional PG adventure film. No blood, no injuries shown - people are pushed and tumble.

STEP 1 - CHECK EVERY FILE FIRST. Before you make anything, open and study each uploaded image one by one:
- 1_CHAR_MONSTER_sheet.jpg = THE MONSTER. A one-eyed protector (a hero, not a villain). Bald, grey cracked skin, ONE big eye in the middle of the forehead, sharp teeth, torn mustard-yellow cloth tunic over one shoulder, brown leather strap across the chest, round metal charms on cords around the neck, rope belt, barefoot. The SCALE panel shows its size: only ONE HEAD taller than a warrior. Never a giant, never a muscular body-builder.
- 2_CHAR_WARRIOR_sheet.jpg = THE WARRIORS. All warriors look exactly like this: dark carved wooden mask with white stripes and red-yellow eye rings, black feathers on top, straw cape on the shoulders, cowrie-shell and bone necklace, white dot body paint, rope belt with a burlap loincloth, rope anklets, spear.
- 4_CHAR_NOOR_sheet.jpg = NOOR. Young woman, brown hair in a ponytail, red and white stripes painted across her forehead and cheeks, dirty white T-shirt, small gold necklace, dirty dark jeans, dark shoes. She never smiles.
- 5_LOC_TEMPLE_COURTYARD_sheet.jpg = THE PLACE. Stone temple courtyard at night: round fire pit with rocks, stone stairs up to a vine-covered temple with a dark doorway and carved stone faces, tiki torches, stone walls, dark jungle around, starry sky. The right panel is our exact camera position, behind the fire pit.
Ignore all printed words and labels on the sheets - they are only notes for you.

STEP 2 - ONCE YOU HAVE CHECKED EVERY FILE, put each character into the video exactly as their reference sheet shows: same face, same costume, same colors, same body size. Do not invent new designs.

STEP 3 - MAKE THE VIDEO.
Make this video 15 seconds, one generation, ONE continuous shot with no cuts.
FIRST FRAME: Use 0_FIRST_FRAME.jpg as the FIRST FRAME (image_to_video). The video starts exactly on this image: THE MONSTER kneeling hurt beside the burning fire pit, NOOR holding it, masked WARRIORS closing in on both sides. Do not draw a new picture.
Characters in this video: THE MONSTER (1_CHAR_MONSTER_sheet.jpg), NOOR (4_CHAR_NOOR_sheet.jpg), THE WARRIORS (2_CHAR_WARRIOR_sheet.jpg). Place: 5_LOC_TEMPLE_COURTYARD_sheet.jpg. No chief.

{
 "title": "Into the Smoke",
 "duration_seconds": 15,
 "aspect_ratio": "16:9",
 "camera": "wide shot from in front of the fire pit, exactly like the first frame, completely still for the whole video. No cuts, no zoom.",
 "shots": [
  {"time": "0-3s", "action": "The WARRIORS step closer with their spears. THE MONSTER looks at the fire, then plunges its big hand straight into the burning fire pit and slams the burning logs down hard into the ashes. It does not get hurt."},
  {"time": "3-5s", "action": "A gigantic wall of thick white-grey smoke and ash explodes out of the fire pit in every direction and rolls toward the camera, swallowing THE MONSTER, NOOR and every WARRIOR."},
  {"time": "5-9s", "action": "The whole picture is COMPLETELY white-grey smoke. Nothing can be seen at all - no people, no temple, no fire. Only a few blurry orange glows of torches move inside the smoke. The WARRIORS are heard coughing and shouting, lost."},
  {"time": "9-12s", "action": "Out of the thick smoke on the right side, THE MONSTER appears, limping and holding its hurt shoulder, pulling NOOR out of the smoke by her hand. NOOR is coughing, covering her mouth with her arm."},
  {"time": "12-15s", "action": "THE MONSTER puts its good arm around NOOR and leads her away to the right, out of the smoke and into the dark jungle at the edge of the courtyard. Behind them the smoke still hides everything."}
 ],
 "rules": "Every character matches its reference sheet. THE MONSTER stays one head taller than NOOR and the warriors. The smoke must be so thick that the screen is fully covered from 5s to 9s.",
 "dialogue": "the warriors cough and shout in an invented tribal language: "KAI! HA-RO!" - no English words. Noor coughs but says nothing.",
 "style": "realistic live-action adventure film, 35mm film grain, deep blue night with warm firelight, then thick white smoke lit orange from the fire, dramatic mood",
 "sound": "crackling fire, a heavy slam into the burning logs, a huge whoosh of smoke, then muffled coughing and shouting in the smoke, the monster's heavy breathing, Noor coughing, footsteps into the jungle. No music.",
 "negative": "monster getting burned, blood, wounds shown, small smoke puff, mushroom cloud, explosion fireball, giant monster, different Noor face, chief, camera movement, cuts, Noor smiling, English words, text, watermark"
}
